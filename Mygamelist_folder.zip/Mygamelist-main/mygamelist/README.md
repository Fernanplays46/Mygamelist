

Stack: Python · FastAPI · SQLModel/SQLite · Jinja2 · Typer (CLI) · Pytest · pdoc

1) Requisitos

Python 3.12 (recomendado)

Windows / macOS / Linux

(Opcional) Git

 ------- Instalación (Windows PowerShell) -------

Si PowerShell bloquea la activación del venv:

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# 1) Ir a la carpeta del proyecto (donde está pyproject.toml)
cd C:\Mygamelist-main\mygamelist

# 2) Crear y activar entorno virtual
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1

# 3) Actualizar pip
python -m pip install -U pip

# 4) Instalar el paquete en editable (hace que 'mgl' sea importable)
python -m pip install -e .

# 5) Dependencias web necesarias (formularios y sesiones)
python -m pip install python-multipart itsdangerous jinja2

# 6) Dependencias de la aplicacion
pip install -r requires.txt


3) Base de datos y datos de ejemplo

El proyecto usa SQLite (archivo mgl.db en la raíz).
Para sembrar datos desde CSV:

python -m mgl.cli seed data\seed\games.csv
# Linux/macOS: python -m mgl.cli seed data/seed/games.csv


Si mgl.db no existe, se crea y migra automáticamente.

4) Ejecutar la aplicación web
python -m uvicorn mgl.api:app --reload


URLs útiles

Home (destacados): http://127.0.0.1:8000/

register: http://127.0.0.1:8000/register

login: http://127.0.0.1:8000/login

Buscador: http://127.0.0.1:8000/buscar?q=zelda

Ficha de juego: http://127.0.0.1:8000/juego/1

Panel Admin: http://127.0.0.1:8000/admin

API docs (Swagger): http://127.0.0.1:8000/docs

Nota: /admin usa formularios (requiere python-multipart) y la app añade middleware de sesiones (requiere itsdangerous).

5) CLI (Typer)
# Sembrar CSV (ver arriba)
python -m mgl.cli seed data\seed\games.csv

# Demo rápida (arranca API y muestra ejemplos)
python -m mgl.cli demo

6) Tests y cobertura
pytest --cov=src\mgl --cov-report=term-missing
# Linux/macOS: pytest --cov=src/mgl --cov-report=term-missing

7) Documentación (pdoc)
python -m pip install pdoc
pdoc -o docs/ src/mgl
# Abrir docs/index.html en el navegador

8) Estructura del proyecto
mygamelist/
├─ src/mgl/
│  ├─ api/
│  │  ├─ __init__.py        # Crea FastAPI app, monta /static, añade routers
│  │  └─ routes.py          # Rutas API JSON + páginas Jinja (/ , /admin, /buscar, ...)
│  ├─ domain/models.py      # Modelos SQLModel: Juego, Favorito
│  ├─ infra/db.py           # Engine, sesiones, create_schema()
│  ├─ repos/juegos.py       # Repositorio (CRUD/búsquedas)
│  └─ cli.py                # Comandos Typer: seed, demo
├─ templates/               # Jinja2: base.html, home.html, results.html, detail.html, admin.html
├─ static/                  # CSS/imagenes opcionales (montado en /static)
├─ data/seed/games.csv      # Datos de ejemplo
├─ tests/                   # Tests unitarios
└─ pyproject.toml

9) Dependencias principales

fastapi

uvicorn

sqlmodel

pydantic

jinja2

requests

python-multipart

bcrypt

10) Rutas principales
API JSON

GET /juegos — lista (filtros: q, genero, plataforma, desde, hasta)

POST /juegos — crea juego

GET /juegos/{id} — detalle

GET /favoritos — lista favoritos

POST /favoritos/{id} — añade favorito

DELETE /favoritos/{id} — quita favorito

Páginas (Jinja)

GET / — Home con destacados

GET /buscar — Resultados

GET /juego/{id} — Ficha

GET /admin — Panel

POST /admin/crear — Crear juego (form)

POST /admin/borrar — Borrar juego (form)


# Notas

Si PowerShell bloquea la activación del entorno virtual, ejecuta una vez:

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
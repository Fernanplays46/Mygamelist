Cambios añadidos:
- Sistema de roles (admin / user)
- Solo admin puede crear, editar y borrar juegos
- Sistema de favoritos (⭐ / 🌟)
- Página /usuarios/favoritos ("Mis Juegos Favoritos")

Usuario admin por defecto:
  usuario: admin
  contraseña: admin123
